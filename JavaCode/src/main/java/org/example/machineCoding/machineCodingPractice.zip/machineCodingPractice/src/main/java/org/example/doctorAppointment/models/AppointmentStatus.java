package org.example.doctorAppointment.models;

public enum AppointmentStatus {
    FAILURE, SUCCESS
}
