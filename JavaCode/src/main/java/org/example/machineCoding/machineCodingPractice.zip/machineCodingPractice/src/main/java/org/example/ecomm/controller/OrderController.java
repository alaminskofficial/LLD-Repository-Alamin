package org.example.ecomm.controller;

import org.example.ecomm.dtos.OrderRequest;
import org.example.ecomm.dtos.OrderResponse;
import org.example.ecomm.models.*;
import org.example.ecomm.services.CartService;
import org.example.ecomm.services.OrderService;
import org.example.ecomm.services.UserService;

import java.util.Date;
import java.util.List;

public class OrderController {
    private OrderService orderService;
    private CartService cartService;
    private UserService userService;

    public OrderController(OrderService orderService, CartService cartService, UserService userService){
        this.orderService = orderService;
        this.cartService = cartService;
        this.userService = userService;
    }
    public OrderResponse placeOrder(OrderRequest orderRequest){
       Order order = new Order();
       order.setUser(userService.getUser(orderRequest.getUserId()));
       order.setCart(cartService.getCart(orderRequest.getCartId()));
       Cart cart = cartService.getCart(orderRequest.getCartId());
       List<CartItem> cartItems = cart.getCartItems();
       Double amount= 0.0;
       for(CartItem cartItem: cartItems){
            amount += cartItem.getProduct().getPrice() * cartItem.getQuantity();
       }
       order.setOrderBillAmount(amount);
       order.setPaymentStats(PaymentStatus.PAYMENT_PENDING);
       order.setStatus(OrderStatus.CONFIRMED);
       Order saveOrder = orderService.saveOrder(order);
       OrderResponse orderResponse = new OrderResponse();
       orderResponse.setOrderId(saveOrder.getId());
       orderResponse.setUserId(saveOrder.getUser().getId());
       orderResponse.setCartId(saveOrder.getCart().getId());
       orderResponse.setOrderStatus(saveOrder.getStatus().name());
       orderResponse.setMessage("Order Placed Successfully");
       orderResponse.setOrderDate(new Date());
       orderResponse.setPaymentStatus(saveOrder.getPaymentStats().name());
       orderResponse.setOrderAmount(saveOrder.getOrderBillAmount());
       return orderResponse;
    }
    public List<Order> getOrdersByUserId(Long userId){
        return orderService.getOrdersByUserId(userId);
    }

}
