package org.example.splitwise.models;

public enum UserExpenseType {
    PAID_BY,HAD_TO_PAY
}
