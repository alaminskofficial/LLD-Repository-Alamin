package org.example.doctorAppointment.models;

import java.util.Date;

public class Appointment extends BaseModel{
    private Long doctorId;
    private Long patientId;
    private Date appointmentDate;
    private String appointmentSlot;
    public Appointment() {
        super();
    }

    public Appointment(Long id ,Long doctorId, Long patientId, Date appointmentDate, String appointmentSlot) {
        super(id);
        this.doctorId = doctorId;
        this.patientId = patientId;
        this.appointmentDate = appointmentDate;
        this.appointmentSlot = appointmentSlot;
    }

    public Long getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(Long doctorId) {
        this.doctorId = doctorId;
    }

    public Long getPatientId() {
        return patientId;
    }

    public void setPatientId(Long patientId) {
        this.patientId = patientId;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public void setAppointmentDate(Date appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public String getAppointmentSlot() {
        return appointmentSlot;
    }

    public void setAppointmentSlot(String appointmentSlot) {
        this.appointmentSlot = appointmentSlot;
    }

    @Override
    public String toString() {
        return "Appointment{" +
                "doctorId=" + doctorId +
                ", patientId=" + patientId +
                ", appointmentDate=" + appointmentDate +
                ", appointmentSlot='" + appointmentSlot + '\'' +
                '}';
    }
}
