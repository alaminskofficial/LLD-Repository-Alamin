package org.example.ecomm.controller;

import org.example.ecomm.dtos.ReviewRequest;
import org.example.ecomm.dtos.ReviewResponse;
import org.example.ecomm.models.Review;
import org.example.ecomm.services.ProductService;
import org.example.ecomm.services.ReviewService;
import org.example.ecomm.services.UserService;

import java.util.Date;

public class ReviewController {
    private ReviewService reviewService;
    private ProductService productService;
    private UserService userService;

    public ReviewController(ReviewService reviewService, ProductService productService, UserService userService){
        this.reviewService = reviewService;
        this.productService = productService;
        this.userService = userService;
    }
    public ReviewResponse addReview(ReviewRequest reviewRequest){
        Review review = new Review();
        review.setProduct(productService.getProduct(reviewRequest.getProductId()));
        review.setUser(userService.getUser(reviewRequest.getUserId()));
        review.setRating(reviewRequest.getRating());
        review.setComment(reviewRequest.getReview());
        Review saveReview = reviewService.saveReview(review);
        ReviewResponse reviewResponse = new ReviewResponse();
        reviewResponse.setUserId(reviewRequest.getUserId());
        reviewResponse.setProductId(reviewRequest.getProductId());
        reviewResponse.setRating(reviewRequest.getRating());
        reviewResponse.setReview(saveReview.getComment());
        reviewResponse.setReviewDate(new Date());
        reviewResponse.setMessage("Thanks for your review!");
        return reviewResponse;
    }


}
