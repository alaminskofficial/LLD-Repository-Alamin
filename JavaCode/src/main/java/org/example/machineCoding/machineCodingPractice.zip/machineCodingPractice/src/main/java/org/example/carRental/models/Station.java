package org.example.carRental.models;

import java.util.List;

public class Station extends  BaseModel{
    private String stationName;
    private String latitude;
    private String longitude;
    private List<Vehicle> vehicleList;

    public Station(Long id, String stationName, String latitude , String longitude, List<Vehicle> vehicleList) {
        super(id);
        this.stationName = stationName;
        this.latitude = latitude;
        this.longitude = longitude;
        this.vehicleList = vehicleList;
    }

    public String getStationName() {
        return stationName;
    }

    public void setStationName(String stationName) {
        this.stationName = stationName;
    }

    public List<Vehicle> getVehicleList() {
        return vehicleList;
    }

    public void setVehicleList(List<Vehicle> vehicleList) {
        this.vehicleList = vehicleList;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    @Override
    public String toString() {
        return "Station{" +
                "stationName='" + stationName + '\'' +
                ", latitude='" + latitude + '\'' +
                ", longitude='" + longitude + '\'' +
                ", vehicleList=" + vehicleList +
                '}';
    }
}
