package org.example.doctorAppointment.services;

import org.example.doctorAppointment.exceptions.PatientDetailsNotFoundException;
import org.example.doctorAppointment.models.Appointment;
import org.example.doctorAppointment.models.Patient;
import org.example.doctorAppointment.repositories.PatientRepository;

import java.util.List;

public class PatientService {
    private PatientRepository patientRepository;
    public PatientService(PatientRepository patientRepository){
        this.patientRepository=patientRepository;
    }
    public Patient savePatient(Patient pat){
        return patientRepository.createPatient(pat);
    }
    public List<Appointment> patientRecords(Long id) throws PatientDetailsNotFoundException {
         Patient pat = patientRepository.getPatById(id);
         if(pat == null){
             throw  new PatientDetailsNotFoundException("Patient Details not Found");
         }
        return patientRepository.patAppointmentRecords(id);
    }
    public Patient getPatById(Long id){
        return patientRepository.getPatById(id);
    }
}
