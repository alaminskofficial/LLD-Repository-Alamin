package org.example.doctorAppointment.controller;

import org.example.doctorAppointment.dtos.AppointmentBookingRequest;
import org.example.doctorAppointment.dtos.AppointmentBookingResponse;
import org.example.doctorAppointment.exceptions.DoctorNotAvailableException;
import org.example.doctorAppointment.exceptions.PatientDetailsNotFoundException;
import org.example.doctorAppointment.models.Appointment;
import org.example.doctorAppointment.models.Doctor;
import org.example.doctorAppointment.models.Patient;
import org.example.doctorAppointment.repositories.AppointMentRepository;
import org.example.doctorAppointment.repositories.DoctorRepository;
import org.example.doctorAppointment.repositories.PatientRepository;
import org.example.doctorAppointment.services.AppointmentService;
import org.example.doctorAppointment.services.DoctorService;
import org.example.doctorAppointment.services.PatientService;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class Client {
    public static void main(String[] args) throws DoctorNotAvailableException, PatientDetailsNotFoundException {
        PatientRepository patientRepository = new PatientRepository();
        DoctorRepository doctorRepository = new DoctorRepository();
        AppointMentRepository appointMentRepository = new AppointMentRepository();

        // create doctor
        DoctorService doctorService = new DoctorService(doctorRepository);
        List<String> availableSlot = Arrays.asList("1-2","2-3","3-4");
        Doctor doctor  = new Doctor(1L,"Khadija","Ortho","k@gmail.com",availableSlot);
        doctorService.saveDoctor(doctor);
        System.out.println(doctor);
        // create patient
        PatientService patientService = new PatientService(patientRepository);
        Patient pat = new Patient(1L,"Alamin","a@gmail.com","12345678");
        patientService.savePatient(pat);
        System.out.println(pat);
       // doctor availability
        List<String> docAvailable = doctorService.availableSlot(1L);
        System.out.println(docAvailable);
       // appointment scheduling
        AppointmentController app = new AppointmentController(doctorService,patientService,new AppointmentService(appointMentRepository));
        AppointmentBookingRequest request = new AppointmentBookingRequest(1L,1L,1L,"1-2",new Date());
        AppointmentBookingResponse response = app.appointmentBooking(request);
        System.out.println(response);
       // patient records
        List<Appointment> records = app.patientRecords(request.getPatientId());
        System.out.println(records);
    }

}
