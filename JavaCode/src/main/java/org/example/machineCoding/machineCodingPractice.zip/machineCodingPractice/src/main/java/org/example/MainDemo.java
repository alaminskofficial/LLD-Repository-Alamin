package org.example;

import java.util.*;
import java.util.stream.*;

class Student {
    private String name;
    private String subject;
    private int marks;

    // Constructor
    public Student(String name, String subject, int marks) {
        this.name = name;
        this.subject = subject;
        this.marks = marks;
    }

    // Getters
    public String getName() {
        return name;
    }

    public String getSubject() {
        return subject;
    }

    public int getMarks() {
        return marks;
    }

    @Override
    public String toString() {
        return "Student{name='" + name + "', subject='" + subject + "', marks=" + marks + "}";
    }
}

public class MainDemo {
    public static void main(String[] args) {
        // Sample list of students
        List<Student> students = Arrays.asList(
                new Student("Alice", "Math", 85),
                new Student("Bob", "Math", 90),
                new Student("Charlie", "Science", 88),
                new Student("David", "Science", 92),
                new Student("Eve", "English", 75),
                new Student("Frank", "English", 80)
        );

        // Find the student with max marks for each subject
        Map<String, Student> topStudentsBySubject = students.stream()
                .collect(Collectors.groupingBy(
                        Student::getSubject, // Group by subject
                        Collectors.collectingAndThen(
                                Collectors.maxBy(Comparator.comparingInt(Student::getMarks)), // Find max marks
                                Optional::get // Extract value from Optional
                        )
                ));

        // Print the result
        topStudentsBySubject.forEach((subject, student) ->
                System.out.println("Top student in " + subject + ": " + student)
        );
    }
}

