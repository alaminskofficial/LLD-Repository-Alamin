package org.example.ecomm.models;

public class User extends BaseModel{
    private String name;
    private String email;
    private UserType userType;
    private String phone;
    private String address;

    public User(Long id, String name, String email, UserType userType, String phone, String address) {
        super(id);
        this.name = name;
        this.email = email;
        this.userType = userType;
        this.phone = phone;
        this.address = address;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public UserType getUserType() {
        return userType;
    }

    public void setUserType(UserType userType) {
        this.userType = userType;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "User{" +
                "id='" + getId() + '\'' +
                "name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", userType=" + userType +
                ", phone='" + phone + '\'' +
                ", address='" + address + '\'' +
                '}';
    }
}
