package org.example.ecomm.controller;

import org.example.ecomm.models.User;
import org.example.ecomm.services.UserService;

public class UserController {
    private UserService userService;
    public UserController(UserService userService){
        this.userService = userService;
    }
    public User saveUser(User user){
        return userService.saveUser(user);
    }
    public User getUser(Long id){
        return userService.getUser(id);
    }
}
