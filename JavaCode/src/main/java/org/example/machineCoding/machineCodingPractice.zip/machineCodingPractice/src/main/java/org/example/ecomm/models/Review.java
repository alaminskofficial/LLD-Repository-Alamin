package org.example.ecomm.models;

public class Review extends BaseModel{
    private String comment;
    private Long rating;
    private Product product;
    private User user;

    public Review() {
    }

    public Review(Long id, String comment, Long rating, Product product, User user) {
        super(id);
        this.comment = comment;
        this.rating = rating;
        this.product = product;
        this.user = user;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public Long getRating() {
        return rating;
    }

    public void setRating(Long rating) {
        this.rating = rating;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
