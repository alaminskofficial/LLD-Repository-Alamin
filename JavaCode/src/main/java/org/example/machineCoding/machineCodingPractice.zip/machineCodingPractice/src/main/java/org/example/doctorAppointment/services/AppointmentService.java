package org.example.doctorAppointment.services;

import org.example.doctorAppointment.models.Appointment;
import org.example.doctorAppointment.repositories.AppointMentRepository;

import java.util.List;

public class AppointmentService {
    private AppointMentRepository appointMentRepository;
    public AppointmentService(AppointMentRepository appointMentRepository){
        this.appointMentRepository = appointMentRepository;
    }
    public Appointment saveAppointment(Appointment app){
        return appointMentRepository.createAppointment(app);
    }
    public List<Appointment> listApp(){
        return appointMentRepository.listApp();
    }
}
