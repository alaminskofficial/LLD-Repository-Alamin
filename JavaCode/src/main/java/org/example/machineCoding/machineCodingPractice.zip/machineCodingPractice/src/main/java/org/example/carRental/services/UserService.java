package org.example.carRental.services;

import org.example.carRental.models.User;
import org.example.carRental.repositories.UserRepository;

import java.util.List;

public class UserService {
    private UserRepository userRepository;
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    public User getUserById(Long id) {
        return userRepository.getUserById(id);
    }
    public User saveUser(User user) {
        return userRepository.saveUser(user);
    }
    public List<User> userList() {
        return userRepository.userList();
    }

}
