package org.example.splitwise.repositories;

import org.example.splitwise.models.Expense;

import java.util.HashMap;
import java.util.Map;

public class ExpenseRepository {
    private Map<Long, Expense> expenseMap;
    public ExpenseRepository() {
        this.expenseMap = new HashMap<>();
    }
    public Expense saveExpense(Expense expense){
        if(expense.getId() == null){
            expense.setId((long) (expenseMap.size() + 1));
        }
        expenseMap.put(expense.getId(), expense);
        return expense;
    }
    public Expense getExpense(Long id){
        return expenseMap.get(id);
    }
}
