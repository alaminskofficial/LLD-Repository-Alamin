package org.example.splitwise.repositories;

import org.example.splitwise.models.User;

import java.util.HashMap;
import java.util.Map;

public class UserRepository {
    private Map<Long, User> userMap;
    public UserRepository() {
        this.userMap = new HashMap<>();
    }
    public User saveUser(User user){
        if(user.getId() == null){
            user.setId((long) (userMap.size() + 1));
        }
        userMap.put(user.getId(), user);
        return user;
    }
    public User getUser(Long id){
        return userMap.get(id);
    }


}
