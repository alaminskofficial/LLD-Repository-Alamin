package org.example;

import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import javax.crypto.Cipher;

public class Encryptor {
    private static final String RSA_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqz7Es/GH7iaU5IZHXkKIYlW5kBETnBHYNyVc9dG0RpwPc6W5SVZNjaWWzngfscXIqjPEIEXPHg/qSjFBn1nq02l3b+lmR/kMY5VCEBGCz/IyGEgoMtER66FIHapEcy2Yd5aWL6bDvQWVIXPj5ZFT3fznkaklPbDGN6YP5zG9Q5Bx/Q7RjxNRLbsCmJSDeoyiwULzK/Xs2kVTzpKYJJ+JODn/h5dOleI7SGkx4dZDN6r4HnGPpNK8JujezBXlkgivmcCUplSWdZ0N3GmUBpcVWOUW2voXd2LkXqLhzT5X5ixWg6ATirTg+wYi7NYM3BhA6w5sJ2bEMf9SLOUZ0NxWaQIDAQAB";
    private static final String RSA_ECB_PKCS1_PADDING = "RSA/ECB/PKCS1Padding";

    public static void main(String[] args) throws Exception {
        // Step 1: Get RSA public key
        PublicKey publicKey = getPublicKey(RSA_PUBLIC_KEY);


        String dataToEncrypt = "VUgrbtTL5R9j7qcUv2mrHEmbDqRcMfHzqxf5X43lWy7X0TFitx1ZqPA1UvZNb+TZS4TX22A5FIrDBHH+Ptj2h6AsStx41EEtJGMSLRdrM/w=";
        dataToEncrypt =Base64.getDecoder().decode(dataToEncrypt.getBytes()).toString();

        // Step 3: Encrypt the output of step 2 using the RSA public key
        byte[] encryptedData = encryptUsingPublicKey(publicKey, dataToEncrypt.getBytes("UTF-8"));

        // Step 4: Encode the output using Base64 twice
        String base64EncodedData = Base64.getEncoder().encodeToString(encryptedData);
        String doubleBase64EncodedData = Base64.getEncoder().encodeToString(base64EncodedData.getBytes());

        System.out.println("Double Base64 Encoded Data: " + doubleBase64EncodedData);
    }

    private static PublicKey getPublicKey(String base64PublicKey) throws Exception {
        byte[] keyBytes = Base64.getDecoder().decode(base64PublicKey);
        X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        return keyFactory.generatePublic(spec);
    }

    private static String sha256(String input) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] hash = digest.digest(input.getBytes("UTF-8"));
        StringBuilder hexString = new StringBuilder();
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
    }

    public static byte[] encryptUsingPublicKey(PublicKey key, byte[] data) {
        byte[] cipherText = null;
        try {
            final Cipher cipher = Cipher.getInstance(RSA_ECB_PKCS1_PADDING);
            cipher.init(Cipher.ENCRYPT_MODE, key);
            cipherText = cipher.doFinal(data);
        } catch (Exception e) {
            e.printStackTrace();
            return Base64.getEncoder().encode(cipherText);
        }
        return cipherText;
    }
}
