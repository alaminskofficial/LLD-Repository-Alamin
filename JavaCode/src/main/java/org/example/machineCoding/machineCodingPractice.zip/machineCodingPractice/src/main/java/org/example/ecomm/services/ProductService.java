package org.example.ecomm.services;

import org.example.ecomm.exceptions.UserNotASellerException;
import org.example.ecomm.models.Product;
import org.example.ecomm.models.UserType;
import org.example.ecomm.repositories.ProductRepository;

import java.util.List;

public class ProductService {
    private ProductRepository productRepository;
    public ProductService(ProductRepository productRepository){
        this.productRepository = productRepository;
    }
    public Product saveProduct(Product product) throws UserNotASellerException {
        if(!product.getSeller().getUserType().equals(UserType.SELLER)){
            throw new UserNotASellerException("Only sellers can add products");
        }
        return productRepository.saveProduct(product);
    }
    public Product getProduct(Long id){
        return productRepository.getProduct(id);
    }
    public List<Product> productList(){
        return productRepository.productList();
    }


}
