package org.example.splitwise.strategies;

import org.example.splitwise.dtos.Transaction;
import org.example.splitwise.models.Pair;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

public class HeapSettlementStrategyImpl implements SettlementStrategy{
    @Override
    public List<Transaction> settleUpGroup(Map<Long, Double> userAmountMap) {
        PriorityQueue<Pair> sender = new PriorityQueue<>();
        PriorityQueue<Pair> receiver = new PriorityQueue<>();
        List<Transaction> transactions = new ArrayList<>();

        for(Long userId : userAmountMap.keySet()){
            Double amount = userAmountMap.get(userId);
            if(amount > 0) {
                receiver.add(new Pair(userId, amount));
            }else if(amount < 0){
                sender.add(new Pair(userId, -1 * amount));
            }
        }
        while(sender.size() > 0 && receiver.size() > 0){
            Pair senderData = sender.poll();
            Pair receiverData = receiver.poll();
            transactions.add(new Transaction(senderData.getUserId().toString(),receiverData.getUserId().toString(),senderData.getAmount()));
            if(senderData.getAmount() < receiverData.getAmount()){
                receiver.add(new Pair(receiverData.getUserId(),receiverData.getAmount() - senderData.getAmount()));
            }
        }return transactions;
    }
}
