package org.example.carRental.controller;

import org.example.carRental.exceptions.StationNotAvailableException;
import org.example.carRental.exceptions.VehicleOfThisTypeNotAvailable;
import org.example.carRental.models.*;
import org.example.carRental.services.StationService;
import org.example.carRental.services.UserService;
import org.example.carRental.services.VehicleService;

import java.util.ArrayList;
import java.util.List;

public class CarRentalController {
    private StationService stationService;
    private VehicleService vehicleService;
    private UserService userService;
    public CarRentalController(StationService stationService, VehicleService vehicleService, UserService userService) {
        this.stationService = stationService;
        this.vehicleService = vehicleService;
        this.userService = userService;
    }


//        Add User
    public User addUser(User user){
        return userService.saveUser(user);
    }
//        Onboard station
    public Station addStation(Station station) {
        return stationService.saveStation(station);
    }
    //    Search Vehicle with type -comparator logic
    public List<Station> searchVehicle(VehicleType type , Long userId){
        User user = userService.getUserById(userId);
        return stationService.searchVehicle(type,user.getUserLatitute(),user.getUserLongitude());
    }
    //        Book vehicle-st1
    public Vehicle bookedVehicle(Long stationId , Long vehicleId) throws VehicleOfThisTypeNotAvailable {
        Vehicle bookedVehicle = null;
        Station station = stationService.getStationById(stationId);
        Vehicle vehicle = vehicleService.getVehicleById(vehicleId);
        if(station.getVehicleList().contains(VehicleStatusType.AVAILABLE)){
            throw  new VehicleOfThisTypeNotAvailable("Vehicle of this Id " + vehicleId + "not available");
        }
        List<Vehicle> vehicleList = station.getVehicleList();
        for(Vehicle v : vehicleList){
            if(v.getId() == vehicleId){
                v.setVehicleStatusType(VehicleStatusType.BOOKED);
                bookedVehicle = vehicleService.saveVehicle(v);
            }
        }return bookedVehicle;


    }
    //        Drop vehicle-st2
    public Vehicle dropedVehicle(Long stationId , Long vehicleId) throws StationNotAvailableException {
        Vehicle droppedVehicle = null;
        Station station = stationService.getStationById(stationId);
        if(station == null) throw new StationNotAvailableException("Station not Available");
        Vehicle vehicle = vehicleService.getVehicleById(vehicleId);
        vehicle.setVehicleStatusType(VehicleStatusType.AVAILABLE);
        droppedVehicle = vehicleService.saveVehicle(vehicle);
        List<Vehicle> list = station.getVehicleList();
        list.add(droppedVehicle);
        stationService.saveStation(station);
        return  droppedVehicle;
    }
    //        Station Report - available car of each type, booked car of each type etc.

    public List<Vehicle> availableVehicle(Long stationId){
        Station station = stationService.getStationById(stationId);
        List<Vehicle> availableStn = new ArrayList<>();
        for(Vehicle veh : station.getVehicleList()){
            if(veh.getVehicleStatusType().equals(VehicleStatusType.AVAILABLE)){
                availableStn.add(veh);
            }
        }return availableStn;
    }
    public List<Vehicle> bookedVehicle(Long stationId){
        Station station = stationService.getStationById(stationId);
        List<Vehicle> bookedStn = new ArrayList<>();
        for(Vehicle veh : station.getVehicleList()){
            if(veh.getVehicleStatusType().equals(VehicleStatusType.BOOKED)){
                bookedStn.add(veh);
            }
        }return bookedStn;
    }


}
