package org.example.wallet.models;

public enum TxnStatus {
    SUCCESS, FAILED
}
