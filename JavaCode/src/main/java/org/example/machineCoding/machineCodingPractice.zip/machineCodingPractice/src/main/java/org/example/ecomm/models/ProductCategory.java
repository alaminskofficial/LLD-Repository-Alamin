package org.example.ecomm.models;

public enum ProductCategory {
    ELECTRONICS,
    FASHION,
    HOME,
    BEAUTY,
    SPORTS,
    TOYS,
    FOOD,
    BOOKS,
    OTHER
}
