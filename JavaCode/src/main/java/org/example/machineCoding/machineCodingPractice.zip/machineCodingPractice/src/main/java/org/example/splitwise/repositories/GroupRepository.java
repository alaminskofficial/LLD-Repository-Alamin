package org.example.splitwise.repositories;

import org.example.splitwise.models.Group;

import java.util.HashMap;
import java.util.Map;

public class GroupRepository {
    private Map<Long, Group> groupMap;
    public GroupRepository() {
        this.groupMap = new HashMap<>();
    }
    public Group saveGroup(Group group){
        if(group.getId() == null){
            group.setId((long) (groupMap.size() + 1));
        }
        groupMap.put(group.getId(), group);
        return group;
    }
    public Group getGroup(Long id){
        return groupMap.get(id);
    }

}
