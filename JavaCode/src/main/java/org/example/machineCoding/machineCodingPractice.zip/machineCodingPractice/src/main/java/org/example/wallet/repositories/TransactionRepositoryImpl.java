package org.example.wallet.repositories;

import org.example.wallet.models.Transaction;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class TransactionRepositoryImpl {
    private Map<Long , Transaction> txnMaps;
    public TransactionRepositoryImpl(){
        this.txnMaps = new HashMap<>();
    }
    public Transaction saveTransaction(Transaction txn){
        if(txn.getTransactionId() == 0L){
            txn.setTransactionId(txnMaps.size() + 1L);
        }
        txnMaps.put(txn.getSenderId(),txn);
        return  txn;
    }
    public List<Transaction> viewTxnList(){
        return txnMaps.values().stream().collect(Collectors.toList());
    }

}
