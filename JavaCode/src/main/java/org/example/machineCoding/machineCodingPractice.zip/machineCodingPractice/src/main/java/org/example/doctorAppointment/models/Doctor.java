package org.example.doctorAppointment.models;

import java.util.List;

public class Doctor  extends BaseModel{
    private String name;
    private String specialization;
    private String email;
    private List<String> availableSlot;

    public Doctor(Long id,String name, String specialization, String email, List<String> availableSlot) {
        super(id);
        this.name = name;
        this.specialization = specialization;
        this.email = email;
        this.availableSlot = availableSlot;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public List<String> getAvailableSlot() {
        return availableSlot;
    }

    public void setAvailableSlot(List<String> availableSlot) {
        this.availableSlot = availableSlot;
    }

    @Override
    public String toString() {
        return "Doctor{" +
                "name='" + name + '\'' +
                ", specialization='" + specialization + '\'' +
                ", email='" + email + '\'' +
                ", availableSlot=" + availableSlot +
                '}';
    }
}
