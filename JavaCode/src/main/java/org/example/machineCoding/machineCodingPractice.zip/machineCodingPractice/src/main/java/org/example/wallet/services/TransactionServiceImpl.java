package org.example.wallet.services;

import org.example.wallet.models.Transaction;
import org.example.wallet.repositories.TransactionRepositoryImpl;
import org.example.wallet.repositories.UserRepositoryImpl;

import java.util.List;

public class TransactionServiceImpl {
    private TransactionRepositoryImpl transactionRepository;
    private UserRepositoryImpl userRepository;
    public TransactionServiceImpl(TransactionRepositoryImpl transactionRepository , UserRepositoryImpl userRepository){
        this.transactionRepository = transactionRepository;
        this.userRepository= userRepository;
    }
    public Transaction saveTransaction(Transaction txn){
        return transactionRepository.saveTransaction(txn);
    }
    public List<Transaction> viewList(){
        return transactionRepository.viewTxnList();
    }
}
