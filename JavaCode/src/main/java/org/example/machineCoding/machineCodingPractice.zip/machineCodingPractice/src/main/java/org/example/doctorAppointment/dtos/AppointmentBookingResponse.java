package org.example.doctorAppointment.dtos;

import java.util.Date;

public class AppointmentBookingResponse {
    private Long doctorId;
    private Long patientId;
    private String scheduleSlot;
    private Date apppointmentDate;
    private String status;

    public Long getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(Long doctorId) {
        this.doctorId = doctorId;
    }

    public Long getPatientId() {
        return patientId;
    }

    public void setPatientId(Long patientId) {
        this.patientId = patientId;
    }

    public String getScheduleSlot() {
        return scheduleSlot;
    }

    public void setScheduleSlot(String scheduleSlot) {
        this.scheduleSlot = scheduleSlot;
    }

    public Date getApppointmentDate() {
        return apppointmentDate;
    }

    public void setApppointmentDate(Date apppointmentDate) {
        this.apppointmentDate = apppointmentDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "AppointmentBookingResponse{" +
                "doctorId=" + doctorId +
                ", patientId=" + patientId +
                ", scheduleSlot='" + scheduleSlot + '\'' +
                ", apppointmentDate=" + apppointmentDate +
                ", status='" + status + '\'' +
                '}';
    }
}
