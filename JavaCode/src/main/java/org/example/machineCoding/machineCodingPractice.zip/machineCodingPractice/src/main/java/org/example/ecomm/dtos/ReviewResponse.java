package org.example.ecomm.dtos;

import java.util.Date;

public class ReviewResponse {
    private Long userId;
    private Long productId;
    private String review;
    private Long rating;
    private Date reviewDate;
    private String message;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public Long getRating() {
        return rating;
    }

    public void setRating(Long rating) {
        this.rating = rating;
    }

    public Date getReviewDate() {
        return reviewDate;
    }

    public void setReviewDate(Date reviewDate) {
        this.reviewDate = reviewDate;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "ReviewResponse{" +
                "userId=" + userId +
                ", productId=" + productId +
                ", review='" + review + '\'' +
                ", rating=" + rating +
                ", reviewDate=" + reviewDate +
                ", message='" + message + '\'' +
                '}';
    }
}
