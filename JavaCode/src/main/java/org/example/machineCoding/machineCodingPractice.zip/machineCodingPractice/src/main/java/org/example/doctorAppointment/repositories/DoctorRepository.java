package org.example.doctorAppointment.repositories;

import org.example.doctorAppointment.models.Doctor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DoctorRepository {
    private Map<Long , Doctor> doctorMap;
    public DoctorRepository(){
        this.doctorMap = new HashMap<>();
    }
    public Doctor saveDoctor(Doctor doctor){
        if(doctor.getId() == 0){
            doctor.setId(doctorMap.size() + 1L);
        }
        doctorMap.put(doctor.getId(),doctor);
        return doctor;
    }
    public List<String> availableSlot(Long doctorId){
        Doctor doctor = doctorMap.get(doctorId);
        return doctor.getAvailableSlot();
    }
    public Doctor getById(Long id){
        return doctorMap.get(id);
    }
}
