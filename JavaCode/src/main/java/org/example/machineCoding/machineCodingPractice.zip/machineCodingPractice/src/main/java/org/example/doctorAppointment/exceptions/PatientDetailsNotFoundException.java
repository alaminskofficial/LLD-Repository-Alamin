package org.example.doctorAppointment.exceptions;

public class PatientDetailsNotFoundException extends Exception{
    public PatientDetailsNotFoundException(String msg){
        super(msg);
    }
}
