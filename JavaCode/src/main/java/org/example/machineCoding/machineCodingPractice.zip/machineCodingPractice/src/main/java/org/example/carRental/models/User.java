package org.example.carRental.models;

public class User extends BaseModel{
    private String username;
    private  String mobNo;
    private String email;
    private String userLatitute;
    private String userLongitude;

    public User(Long id, String username, String mobNo, String email, String userLatitute, String userLongitude) {
        super(id);
        this.username = username;
        this.mobNo = mobNo;
        this.email = email;
        this.userLatitute = userLatitute;
        this.userLongitude = userLongitude;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getMobNo() {
        return mobNo;
    }

    public void setMobNo(String mobNo) {
        this.mobNo = mobNo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUserLatitute() {
        return userLatitute;
    }

    public void setUserLatitute(String userLatitute) {
        this.userLatitute = userLatitute;
    }

    public String getUserLongitude() {
        return userLongitude;
    }

    public void setUserLongitude(String userLongitude) {
        this.userLongitude = userLongitude;
    }

    @Override
    public String toString() {
        return "User{" +
                "username='" + username + '\'' +
                ", mobNo='" + mobNo + '\'' +
                ", email='" + email + '\'' +
                ", userLatitute='" + userLatitute + '\'' +
                ", userLongitude='" + userLongitude + '\'' +
                '}';
    }
}
