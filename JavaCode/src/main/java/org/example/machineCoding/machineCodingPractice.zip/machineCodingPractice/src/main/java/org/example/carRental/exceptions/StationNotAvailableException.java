package org.example.carRental.exceptions;

public class StationNotAvailableException extends Throwable {
    public StationNotAvailableException(String stationNotAvailable) {
        super(stationNotAvailable);
    }
}
