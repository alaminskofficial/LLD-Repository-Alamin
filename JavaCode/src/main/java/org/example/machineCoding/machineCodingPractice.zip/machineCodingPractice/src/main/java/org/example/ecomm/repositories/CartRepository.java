package org.example.ecomm.repositories;

import org.example.ecomm.models.Cart;
import org.example.ecomm.models.CartItem;

import java.util.*;

public class CartRepository {
    private Map<Long, Cart> cartMap;
    public CartRepository() {
        this.cartMap = new HashMap<>();
    }
    public Cart saveCart(Cart cart){
        if(cart.getId() == null){
            cart.setId((long) (cartMap.size()+1));
        }
        cartMap.put(cart.getId(), cart);
        return cart;
    }
    public Cart getCart(Long id){
        return cartMap.get(id);
    }
    public Cart getCartByUserId(Long userId){
        for(Cart cart : cartMap.values()){
            if(cart.getUserId().equals(userId)){
                return cart;
            }
        }
        return null;
    }



}
