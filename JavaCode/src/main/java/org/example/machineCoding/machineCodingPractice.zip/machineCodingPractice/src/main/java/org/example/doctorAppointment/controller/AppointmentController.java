package org.example.doctorAppointment.controller;

import org.example.doctorAppointment.dtos.AppointmentBookingRequest;
import org.example.doctorAppointment.dtos.AppointmentBookingResponse;
import org.example.doctorAppointment.exceptions.DoctorNotAvailableException;
import org.example.doctorAppointment.exceptions.PatientDetailsNotFoundException;
import org.example.doctorAppointment.models.Appointment;
import org.example.doctorAppointment.models.AppointmentStatus;
import org.example.doctorAppointment.models.Doctor;
import org.example.doctorAppointment.models.Patient;
import org.example.doctorAppointment.services.AppointmentService;
import org.example.doctorAppointment.services.DoctorService;
import org.example.doctorAppointment.services.PatientService;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AppointmentController {
    private DoctorService doctorService;
    private PatientService patientService;
    private AppointmentService appointmentService;

    public AppointmentController(DoctorService doctorService, PatientService patientService, AppointmentService appointmentService) {
        this.doctorService = doctorService;
        this.patientService = patientService;
        this.appointmentService = appointmentService;
    }
    //    doctor availability
    public List<String> doctorAvailbility(Long id){
        return doctorService.availableSlot(id);
    }
//    appointment scheduling
    public AppointmentBookingResponse appointmentBooking(AppointmentBookingRequest request) throws DoctorNotAvailableException {
        AppointmentBookingResponse response = new AppointmentBookingResponse();
        Appointment appointment = new Appointment();
        appointment.setId(request.getId());
        appointment.setDoctorId(request.getDoctorId());
        appointment.setPatientId(request.getPatientId());
        appointment.setAppointmentDate(request.getApppointmentDate());
        appointment.setAppointmentSlot(request.getScheduleSlot());
        Appointment outApp= appointmentService.saveAppointment(appointment);
        Patient patient = patientService.getPatById(request.getPatientId());
        List<Appointment> apps = patient.getAppHistory();
        apps.add(appointment);
        patient.setAppHistory(apps);
        patientService.savePatient(patient);
        response.setDoctorId(request.getDoctorId());
        response.setPatientId(request.getPatientId());
        if(outApp != null){
            response.setStatus(AppointmentStatus.SUCCESS.name());
        }else{
            response.setStatus(AppointmentStatus.FAILURE.name());
        }
        Doctor doctor = doctorService.getDocById(request.getDoctorId());
        List<String>  docAvailableSlot = doctorService.availableSlot(doctor.getId());
        if(!docAvailableSlot.contains(request.getScheduleSlot())){
            throw new DoctorNotAvailableException("Doctor Not Available");
        }
        response.setScheduleSlot(request.getScheduleSlot());
        response.setApppointmentDate(new Date());
        return  response;
    }
//    patient records
    public List<Appointment> patientRecords(Long patId) throws PatientDetailsNotFoundException {
        Patient pat = patientService.getPatById(patId);
        if(pat == null) throw  new PatientDetailsNotFoundException("Patient Details Not Found");
        return  patientService.patientRecords(patId);
    }

}
