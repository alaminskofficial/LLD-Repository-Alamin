package org.example.ecomm.models;

import java.util.List;

public class Cart extends BaseModel{
    private List<CartItem> cartItems;
    private Long userId;
    public Cart() {
    }
    public Cart(Long id, List<CartItem> cartItems, Long userId) {
        super(id);
        this.cartItems = cartItems;
        this.userId = userId;
    }

    public List<CartItem> getCartItems() {
        return cartItems;
    }

    public void setCartItems(List<CartItem> cartItems) {
        this.cartItems = cartItems;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }
}
