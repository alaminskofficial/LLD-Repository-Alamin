package org.example.ecomm.controller;

import org.example.ecomm.dtos.PaymentRequest;
import org.example.ecomm.dtos.PaymentResponse;
import org.example.ecomm.models.Order;
import org.example.ecomm.models.Payment;
import org.example.ecomm.services.OrderService;
import org.example.ecomm.services.PaymentService;
import org.example.ecomm.models.PaymentStatus;

import java.util.Date;

public class PaymentController {
    private PaymentService paymentService;
    public OrderService orderService;
    public PaymentController(PaymentService paymentService, OrderService orderService){
        this.paymentService = paymentService;
        this.orderService = orderService;
    }
    public PaymentResponse  makePayment(PaymentRequest paymentRequest){
        Order order = orderService.getOrder(paymentRequest.getOrderId());
        Payment payment = new Payment();
        payment.setOrderId(paymentRequest.getOrderId());
        payment.setPaymentMethod(paymentRequest.getPaymentMethod());
        payment.setUserId(paymentRequest.getUserId());
        payment.setOrderBillAmount(order.getOrderBillAmount());
        payment.setPaymentStatus(PaymentStatus.PAYMENT_SUCCESSFUL);
        Payment savePayment = paymentService.savePayment(payment);
        PaymentResponse paymentResponse = new PaymentResponse();
        paymentResponse.setPaymentId(savePayment.getId());
        paymentResponse.setOrderId(savePayment.getOrderId());
        paymentResponse.setPaymentStatus(savePayment.getPaymentStatus().name());
        paymentResponse.setMessage("Payment Successful");
        paymentResponse.setPaymentDate(new Date());
        paymentResponse.setOrderBillAmount(savePayment.getOrderBillAmount());
        paymentResponse.setUserId(savePayment.getUserId());
        paymentResponse.setPaymentMethod(savePayment.getPaymentMethod());
        return paymentResponse;
    }

}
