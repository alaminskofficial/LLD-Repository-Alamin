package org.example.wallet.controller;

import org.example.wallet.dtos.TransactionRequest;
import org.example.wallet.dtos.TransactionResponse;
import org.example.wallet.exceptions.SufficientBalanceNotAvailableException;
import org.example.wallet.exceptions.UserNotFoundException;
import org.example.wallet.models.Transaction;
import org.example.wallet.models.TxnStatus;
import org.example.wallet.models.User;
import org.example.wallet.services.TransactionServiceImpl;
import org.example.wallet.services.UserServiceImpl;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public class WalletController {
    private UserServiceImpl userService;
    private TransactionServiceImpl transactionService;
    public WalletController(UserServiceImpl userService , TransactionServiceImpl transactionService){
        this.userService = userService;
        this.transactionService= transactionService;
    }
    //        adding fund
//        transferring money between users
//        view txn history etc
    public User addFundToWallet(BigDecimal amount, Long userId) throws UserNotFoundException {
        return userService.addFundToUserWallet(amount,userId);
    }
    public TransactionResponse transferMoney(TransactionRequest request) throws UserNotFoundException, SufficientBalanceNotAvailableException {
        userService.sendMoney(request.getSenderId() , request.getReceiverId(), BigDecimal.valueOf(40));
        Transaction txn = new Transaction(100L, request.getSenderId(), request.getReceiverId(), request.getTxnAmount(),null);
        Transaction txnResp = transactionService.saveTransaction(txn);
        TransactionResponse response = new TransactionResponse();
        response.setSender(userService.findUserById(txnResp.getSenderId()).get());
        response.setReceiver(userService.findUserById(txnResp.getReceiverId()).get());
        response.setTxnDateTime(null);
        response.setTxnStatus(txnResp != null ? TxnStatus.SUCCESS.name() : TxnStatus.FAILED.name());
        return  response;

    }
    public List<Transaction> viewHistory(){
        return transactionService.viewList();
    }
}
