package org.example.doctorAppointment.repositories;

import org.example.doctorAppointment.models.Appointment;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class AppointMentRepository {
    private Map<Long , Appointment> appMaps;
    public AppointMentRepository(){
        this.appMaps = new HashMap<>();
    }
    public Appointment createAppointment(Appointment app){
        if(app.getId() == 0L){
            app.setId(appMaps.size() + 1L);
        }
        appMaps.put(app.getId(), app);
        return app;
    }
    public List<Appointment> listApp(){
        return appMaps.values().stream().collect(Collectors.toList());
    }
}
