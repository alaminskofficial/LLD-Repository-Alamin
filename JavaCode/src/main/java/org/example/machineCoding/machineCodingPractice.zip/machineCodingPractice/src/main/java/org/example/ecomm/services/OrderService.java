package org.example.ecomm.services;

import org.example.ecomm.models.Order;
import org.example.ecomm.repositories.OrderRepository;

import java.util.List;

public class OrderService {
    private OrderRepository orderRepository;
    public OrderService(OrderRepository orderRepository){
        this.orderRepository = orderRepository;
    }
    public Order saveOrder(Order order){
        return orderRepository.saveOrder(order);
    }
    public Order getOrder(Long id){
        return orderRepository.getOrder(id);
    }
    public List<Order> getOrdersByUserId(Long userId){
        return orderRepository.getOrdersByUserId(userId);
    }
}
