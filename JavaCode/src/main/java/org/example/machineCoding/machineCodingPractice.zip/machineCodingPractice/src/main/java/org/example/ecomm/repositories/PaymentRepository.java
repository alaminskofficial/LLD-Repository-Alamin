package org.example.ecomm.repositories;

import org.example.ecomm.models.Payment;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class PaymentRepository {
    private Map<Long, Payment> paymentMap;
    public PaymentRepository() {
        this.paymentMap = new HashMap<>();
    }
    public Payment savePayment(Payment payment){
        if(payment.getId() == null){
            payment.setId((long) (paymentMap.size()+1));
        }
        paymentMap.put(payment.getId(), payment);
        return payment;
    }
    public Payment getPayment(Long id){
        return paymentMap.get(id);
    }
    public List<Payment> paymentList(){
        return paymentMap.values().stream().collect(Collectors.toList());
    }
    public Payment getPaymentByOrderId(Long orderId){
        for(Payment payment : paymentMap.values()){
            if(payment.getOrderId().equals(orderId)){
                return payment;
            }
        }
        return null;
    }

}
