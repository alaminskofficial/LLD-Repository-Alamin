package org.example.doctorAppointment.services;

import org.example.doctorAppointment.models.Doctor;
import org.example.doctorAppointment.repositories.DoctorRepository;

import java.util.List;

public class DoctorService {
    private DoctorRepository doctorRepository;
    public DoctorService(DoctorRepository doctorRepository){
        this.doctorRepository = doctorRepository;
    }
    public Doctor saveDoctor(Doctor doc){
        return doctorRepository.saveDoctor(doc);
    }
    public List<String> availableSlot(Long id){
        return doctorRepository.availableSlot(id);
    }
    public Doctor getDocById(Long id){
        return doctorRepository.getById(id);
    }
}
