package org.example.ecomm.models;

public class Order extends BaseModel{
    private Cart cart;
    private User user;
    private Double orderBillAmount;
    private PaymentStatus paymentStats;
    private OrderStatus status;
    public Order() {
    }
    public Order(Long id, Cart cart, User user, Double orderBillAmount,PaymentStatus paymentStats, OrderStatus status) {
        super(id);
        this.cart = cart;
        this.user = user;
        this.orderBillAmount = orderBillAmount;
        this.paymentStats = paymentStats;
        this.status = status;
    }

    public Cart getCart() {
        return cart;
    }

    public void setCart(Cart cart) {
        this.cart = cart;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Double getOrderBillAmount() {
        return orderBillAmount;
    }

    public void setOrderBillAmount(Double orderBillAmount) {
        this.orderBillAmount = orderBillAmount;
    }

    public PaymentStatus getPaymentStats() {
        return paymentStats;
    }

    public void setPaymentStats(PaymentStatus paymentStats) {
        this.paymentStats = paymentStats;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Order{" +
                "cart=" + cart +
                ", user=" + user +
                ", paymentStats=" + paymentStats +
                ", status=" + status +
                '}';
    }
}
