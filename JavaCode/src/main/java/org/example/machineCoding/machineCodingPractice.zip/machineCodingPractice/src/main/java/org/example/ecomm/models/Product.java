package org.example.ecomm.models;

public class Product extends BaseModel{
       private String name;
        private String description;
        private Double price;
        private Long quantity;
        private ProductCategory productCategory;
        private User seller;

        public Product() {
        }
        public Product(Long id, String name, String description, Double price, Long quantity, ProductCategory productCategory, User seller) {
            super(id);
            this.name = name;
            this.description = description;
            this.price = price;
            this.quantity = quantity;
            this.productCategory = productCategory;
            this.seller = seller;
        }
        //getter and setter

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Long getQuantity() {
        return quantity;
    }

    public void setQuantity(Long quantity) {
        this.quantity = quantity;
    }

    public ProductCategory getProductCategory() {
        return productCategory;
    }

    @Override
    public String toString() {
        return "Product{" +
                "id='" + getId() + '\'' +
                "name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", price=" + price +
                ", quantity=" + quantity +
                ", productCategory=" + productCategory +
                '}';
    }

    public void setProductCategory(ProductCategory productCategory) {
        this.productCategory = productCategory;
    }

    public User getSeller() {
        return seller;
    }
    public void setSeller(User seller) {
        this.seller = seller;
    }

}
