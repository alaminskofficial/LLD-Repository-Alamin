package org.example.carRental.exceptions;

public class VehicleOfThisTypeNotAvailable extends Throwable {
    public VehicleOfThisTypeNotAvailable(String s) {
        super(s);
    }
}
