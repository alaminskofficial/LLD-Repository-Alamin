package org.example.carRental.repositories;

import org.example.carRental.models.Vehicle;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class VehicleRepository {
    private Map<Long , Vehicle> vehicleMap;

    public VehicleRepository(){
        this.vehicleMap = new HashMap<>();
    }
    public Vehicle saveVehicle(Vehicle vehicle){
        if(vehicle.getId() == null){
            vehicle.setId(vehicleMap.size() + 1L);
        }
        vehicleMap.put(vehicle.getId(), vehicle);
        return vehicle;
    }
    public Vehicle getVehicleById(Long vehicleId){
        return vehicleMap.get(vehicleId);
    }
    public List<Vehicle> vehicleList(){
        return vehicleMap.values().stream().collect(Collectors.toList());
    }
    public void deleteVehicle(Long vehicleId){
        vehicleMap.remove(vehicleId);
    }

}
