package org.example.carRental.services;

import org.example.carRental.models.Station;
import org.example.carRental.models.Vehicle;
import org.example.carRental.models.VehicleStatusType;
import org.example.carRental.models.VehicleType;
import org.example.carRental.repositories.StationRepository;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class StationService {
    private StationRepository stationRepository;
    public StationService(StationRepository stationRepository) {
        this.stationRepository = stationRepository;
    }
    public Station getStationById(Long id) {
        return stationRepository.getStationById(id);
    }
    public Station saveStation(Station station) {
        return stationRepository.saveStation(station);
    }
    public void deleteStation(Long id) {
        stationRepository.deleteStation(id);
    }
    public List<Station> stationList() {
        return stationRepository.stationList();
    }
    public List<Station> searchVehicle(VehicleType type , String customerLatitude , String customerLongitude){
        List<Station> availableStations = new ArrayList<>();
        for(Station st : stationRepository.stationList()){
            List<Vehicle> availableVehicles = st.getVehicleList().stream()
                    .filter(vehicle -> vehicle.getVehicleStatusType().equals(VehicleStatusType.AVAILABLE))
                    .collect(Collectors.toList());
            if (!availableVehicles.isEmpty()) {
                availableStations.add(st);
            }
        }
        Collections.sort(availableStations , new Comparator<Station>() {
            @Override
            public int compare(Station o1, Station o2) {
                System.out.println("Comparing " + o1.getStationName() + " and " + o2.getStationName());
                // compare the price if same compare the station distance
                double price1 = o1.getVehicleList().get(0).getRentPerHour();
                double price2 = o2.getVehicleList().get(0).getRentPerHour();
                int priceCompare = Double.compare(price1, price2);
                if(priceCompare != 0){
                    return  priceCompare;
                }
                double distance1 = calculateDistance(Double.parseDouble( o1.getLatitude()), Double.parseDouble(o1.getLongitude()), Double.parseDouble(customerLatitude), Double.parseDouble(customerLongitude));
                double distance2 = calculateDistance(Double.parseDouble(o2.getLatitude()),Double.parseDouble(o2.getLongitude()), Double.parseDouble(customerLatitude), Double.parseDouble(customerLongitude));
                return Double.compare(distance1, distance2);
            }
        });
        return  availableStations;

    }

    private double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
        double earthRadius = 6371; // Radius of Earth in km
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        //(Haversine Formula):
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                        Math.sin(dLon / 2) * Math.sin(dLon / 2);

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return earthRadius * c; // Distance in km
    }

}
