package org.example.carRental.models;

public enum VehicleStatusType {
    BOOKED,AVAILABLE
}
