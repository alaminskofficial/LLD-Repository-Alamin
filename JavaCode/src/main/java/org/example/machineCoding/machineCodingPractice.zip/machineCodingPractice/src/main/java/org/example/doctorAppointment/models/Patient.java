package org.example.doctorAppointment.models;

import java.util.ArrayList;
import java.util.List;

public class Patient  extends BaseModel{
    private String name;
    private String email;
    private String mobile;
    private List<Appointment> appHistory;

    public Patient(Long id ,String name, String email, String mobile) {
        super(id);
        this.name = name;
        this.email = email;
        this.mobile = mobile;
        this.appHistory = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public List<Appointment> getAppHistory() {
        return appHistory;
    }

    public void setAppHistory(List<Appointment> appHistory) {
        this.appHistory = appHistory;
    }

    @Override
    public String toString() {
        return "Patient{" +
                "name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", mobile='" + mobile + '\'' +
                ", appHistory=" + appHistory +
                '}';
    }
}
