package org.example.ecomm.exceptions;

public class UserNotASellerException extends Exception{
    public UserNotASellerException(String message){
        super(message);
    }
}
