package org.example.splitwise.models;

import java.util.ArrayList;
import java.util.List;

public class Group extends BaseModel{
    private String name;
    private List<User> members;
    private List<Expense> expenses;

    public Group(Long id, String name) {
        super(id);
        this.name = name;
        this.members = new ArrayList<>();
        this.expenses = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<User> getMembers() {
        return members;
    }

    public void setMembers(List<User> members) {
        this.members = members;
    }

    public List<Expense> getExpenses() {
        return expenses;
    }

    public void setExpenses(List<Expense> expenses) {
        this.expenses = expenses;
    }
}
