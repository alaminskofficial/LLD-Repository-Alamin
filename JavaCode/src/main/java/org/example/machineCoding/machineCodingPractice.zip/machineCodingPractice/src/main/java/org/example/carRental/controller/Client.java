package org.example.carRental.controller;
/*
@Author : Sk Alamin
 */

import org.example.carRental.exceptions.StationNotAvailableException;
import org.example.carRental.exceptions.VehicleOfThisTypeNotAvailable;
import org.example.carRental.models.*;
import org.example.carRental.repositories.StationRepository;
import org.example.carRental.repositories.UserRepository;
import org.example.carRental.repositories.VehicleRepository;
import org.example.carRental.services.StationService;
import org.example.carRental.services.UserService;
import org.example.carRental.services.VehicleService;

import java.util.ArrayList;
import java.util.List;

//        Requirement -
//
//
//        This rental system will have some stations where car will be parked.
//        Every station will have some type of cars (example - SUV, Hatchback, Bike, Sedan etc) and will have some fixed price for each type of car ($11/hour for SUV, 12$/per hour for Sedan etc.)
//        User can book car from any station and drop at same or any other station
//        When user searches for a car - list all stations with that type of available car + station with cheapest price should be on top followed by second cheapest and so on..(order by increasing per hour price)
//        When two stations have same price, list station nearest to the customer
//        Supported operations
public class Client {
    public static void main(String[] args) throws VehicleOfThisTypeNotAvailable, StationNotAvailableException {
        StationRepository stationRepository = new StationRepository();
        VehicleRepository vehicleRepository = new VehicleRepository();
        UserRepository userRepository = new UserRepository();
        UserService userService = new UserService(userRepository);
        VehicleService vehicleService = new VehicleService(vehicleRepository);
//        Add User
        User alamin = new User(null , "alaminsk" , "12345" , "al@gmail.com","13.0827","80.2707");
        User onboardedUser = userService.saveUser(alamin);
//        Onboard station - (station_name, List
        List<Vehicle> vehicleListStn1 = new ArrayList<>();
        Vehicle veh1 = new Vehicle(null , VehicleType.BIKE,10.23 , VehicleStatusType.AVAILABLE);
        Vehicle veh2 = new Vehicle(null , VehicleType.SUV,50.78 , VehicleStatusType.AVAILABLE);
        Vehicle veh3 = new Vehicle(null , VehicleType.SEDAN,45.26 , VehicleStatusType.AVAILABLE);
        Vehicle veh4 = new Vehicle(null , VehicleType.BIKE,10.3 , VehicleStatusType.AVAILABLE);
        vehicleListStn1.add(veh1);
        vehicleListStn1.add(veh2);
        vehicleListStn1.add(veh3);
        vehicleListStn1.add(veh4);
        vehicleService.saveAll(vehicleListStn1);
        Station stn1 = new Station(null , "Chennai1","13.07","80.29",vehicleListStn1);
        StationService stationService = new StationService(stationRepository);
        Station chennaiStn = stationService.saveStation(stn1);
        System.out.println(chennaiStn);
        List<Vehicle> vehicleListStn2 = new ArrayList<>();
        Vehicle veh11 = new Vehicle(null , VehicleType.BIKE,19.29 , VehicleStatusType.AVAILABLE);
        Vehicle veh22 = new Vehicle(null , VehicleType.SUV,60.18 , VehicleStatusType.AVAILABLE);
        Vehicle veh33 = new Vehicle(null , VehicleType.SEDAN,55.96 , VehicleStatusType.AVAILABLE);
        Vehicle veh44 = new Vehicle(null , VehicleType.BIKE,10.23 , VehicleStatusType.AVAILABLE);
        vehicleListStn2.add(veh11);
        vehicleListStn2.add(veh22);
        vehicleListStn2.add(veh33);
        vehicleListStn2.add(veh44);
        vehicleService.saveAll(vehicleListStn1);
        Station stn2 = new Station(null , "Blr2","12.9716","77.5946",vehicleListStn2);
        Station blrStn = stationService.saveStation(stn2);
        System.out.println(stn2);
        CarRentalController controller = new CarRentalController(stationService,vehicleService,userService);
        //Search Vehicle
        //price and distance wise sort the station list
        List<Station> searchVehiclePresent = controller.searchVehicle(VehicleType.BIKE,1L);
        System.out.println(searchVehiclePresent);
        Vehicle bookedVehicle = null;
        Station decideStnIdAfterSorting = null;
//        Book vehicle-st1
        if(searchVehiclePresent.size() > 0) {
            decideStnIdAfterSorting = searchVehiclePresent.get(0);
            Vehicle decideVehicle = decideStnIdAfterSorting.getVehicleList().get(0);
            bookedVehicle = controller.bookedVehicle(decideStnIdAfterSorting.getId(), decideVehicle.getId());
            System.out.println(bookedVehicle);
        }
        List<Vehicle> bookedVehicles = controller.bookedVehicle(decideStnIdAfterSorting.getId());
        System.out.println(bookedVehicles);
        
//        Drop vehicle-st2
        Vehicle droppedVehicle = controller.dropedVehicle(2l,bookedVehicle.getId());
        System.out.println(droppedVehicle);

//        Station Report - available car of each type, booked car of each type etc.
        List<Vehicle> availbleVehicle = controller.availableVehicle(decideStnIdAfterSorting.getId());
        System.out.println(availbleVehicle);

    }
}
