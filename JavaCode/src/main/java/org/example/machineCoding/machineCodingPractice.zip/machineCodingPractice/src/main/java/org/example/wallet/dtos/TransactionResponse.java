package org.example.wallet.dtos;

import org.example.wallet.models.User;

import java.time.LocalDateTime;

public class TransactionResponse {
    private User sender;
    private User receiver;
    private String txnStatus;
    private LocalDateTime txnDateTime;

    public User getSender() {
        return sender;
    }

    public void setSender(User sender) {
        this.sender = sender;
    }

    public User getReceiver() {
        return receiver;
    }

    public void setReceiver(User receiver) {
        this.receiver = receiver;
    }

    public String getTxnStatus() {
        return txnStatus;
    }

    public void setTxnStatus(String txnStatus) {
        this.txnStatus = txnStatus;
    }

    public LocalDateTime getTxnDateTime() {
        return txnDateTime;
    }

    public void setTxnDateTime(LocalDateTime txnDateTime) {
        this.txnDateTime = txnDateTime;
    }

    @Override
    public String toString() {
        return "TransactionResponse{" +
                "sender=" + sender +
                ", receiver=" + receiver +
                ", txnStatus='" + txnStatus + '\'' +
                ", txnDateTime=" + txnDateTime +
                '}';
    }
}
