package org.example.doctorAppointment.repositories;

import org.example.doctorAppointment.models.Appointment;
import org.example.doctorAppointment.models.Patient;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PatientRepository {
    private Map<Long , Patient> patientMap;
    public PatientRepository(){
        this.patientMap= new HashMap<>();
    }
    public Patient createPatient(Patient pat){
        if(pat.getId() == 0){
            pat.setId(patientMap.size() + 1L);
        }
        patientMap.put(pat.getId(),pat);
        return  pat;
    }
    public Patient getPatById(Long id){
        return patientMap.get(id);
    }
    public List<Appointment> patAppointmentRecords(Long patId){
        Patient pat = patientMap.get(patId);
        return pat.getAppHistory();
    }
}
