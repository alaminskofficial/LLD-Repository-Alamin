package org.example.wallet.repositories;

import org.example.wallet.models.User;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class UserRepositoryImpl {
    private Map<Long , User>  userMap;
    public UserRepositoryImpl(){
        this.userMap = new HashMap<>();
    }
    public  User saveUser(User user){
        if(user.getUserId() == 0L){
            user.setUserId(userMap.size() + 1L);
        }
        userMap.put(user.getUserId() , user);
        return  user;
    }
    public Optional<User> findUserById(Long id){
        return Optional.ofNullable(userMap.get(id));
    }

}
