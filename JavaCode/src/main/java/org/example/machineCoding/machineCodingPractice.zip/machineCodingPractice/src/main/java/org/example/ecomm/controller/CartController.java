package org.example.ecomm.controller;

import org.example.ecomm.dtos.CartRequest;
import org.example.ecomm.dtos.CartResponse;
import org.example.ecomm.models.Cart;
import org.example.ecomm.services.CartService;

public class CartController {
    private CartService cartService;
    public CartController(CartService cartService){
        this.cartService = cartService;
    }
    public CartResponse addToCart(CartRequest cartRequest){
        Cart cart = new Cart();
        cart.setUserId(cartRequest.getUserId());
        cart.setCartItems(cartRequest.getCartItems());
        Cart savedCart = cartService.saveCart(cart);
        CartResponse response = new CartResponse();
        response.setUserId(savedCart.getUserId());
        response.setCartItems(savedCart.getCartItems());
        response.setStatus("SUCCESS");
        response.setMessage("Items added to cart successfully");
        return response;
    }
    public Cart updateCart(CartRequest cartRequest){
        Cart cart = cartService.getCartByUserId(cartRequest.getUserId());
        cart.setCartItems(cartRequest.getCartItems());
        return cartService.saveCart(cart);
    }
    public Cart getCart(Long userId){
        return cartService.getCartByUserId(userId);
    }
}
