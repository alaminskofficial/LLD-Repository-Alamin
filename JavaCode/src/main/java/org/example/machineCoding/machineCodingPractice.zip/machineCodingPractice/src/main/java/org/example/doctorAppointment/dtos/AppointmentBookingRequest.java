package org.example.doctorAppointment.dtos;

import org.example.doctorAppointment.models.BaseModel;

import java.util.Date;

public class AppointmentBookingRequest extends BaseModel {
    private Long doctorId;
    private Long patientId;
    private String scheduleSlot;
    private Date apppointmentDate;

    public AppointmentBookingRequest(Long id,Long doctorId, Long patientId, String scheduleSlot, Date apppointmentDate) {
        this.setId(id);
        this.doctorId = doctorId;
        this.patientId = patientId;
        this.scheduleSlot = scheduleSlot;
        this.apppointmentDate = apppointmentDate;
    }

    public Long getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(Long doctorId) {
        this.doctorId = doctorId;
    }

    public Long getPatientId() {
        return patientId;
    }

    public void setPatientId(Long patientId) {
        this.patientId = patientId;
    }

    public String getScheduleSlot() {
        return scheduleSlot;
    }

    public void setScheduleSlot(String scheduleSlot) {
        this.scheduleSlot = scheduleSlot;
    }

    public Date getApppointmentDate() {
        return apppointmentDate;
    }

    public void setApppointmentDate(Date apppointmentDate) {
        this.apppointmentDate = apppointmentDate;
    }
}
