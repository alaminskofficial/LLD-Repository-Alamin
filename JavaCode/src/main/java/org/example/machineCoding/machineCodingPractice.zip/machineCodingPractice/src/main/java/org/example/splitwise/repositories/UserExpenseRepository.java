package org.example.splitwise.repositories;

import org.example.splitwise.models.UserExpense;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserExpenseRepository {
    private Map<Long , UserExpense> userExpenseMap;
    public UserExpenseRepository() {
        this.userExpenseMap = new HashMap<>();
    }
    public UserExpense saveUserExpense(UserExpense userExpense){
        if(userExpense.getId() == null){
            userExpense.setId((long) (userExpenseMap.size() + 1));
        }
        userExpenseMap.put(userExpense.getId(), userExpense);
        return userExpense;
    }
    public UserExpense getUserExpense(Long id){
        return userExpenseMap.get(id);
    }
    public List<UserExpense> getUserExpensesByExpenseId(Long expenseId){
        List<UserExpense> userExpenses = new ArrayList<>();
        for(UserExpense userExpense : userExpenseMap.values()){
            if(userExpense.getExpense().getId().equals(expenseId)){
                userExpenses.add(userExpense);
            }
        }
        return userExpenses;
    }
}
