package org.example.ecomm.services;

import org.example.ecomm.models.Review;
import org.example.ecomm.repositories.ReviewRepository;

import java.util.List;

public class ReviewService {
    private ReviewRepository reviewRepository;
    public ReviewService(ReviewRepository reviewRepository){
        this.reviewRepository = reviewRepository;
    }
    public Review saveReview(Review review){
        return reviewRepository.saveReview(review);
    }
    public Review getReview(Long id){
        return reviewRepository.getReview(id);
    }
    public List<Review> getReviewsByProductId(Long productId){
        return reviewRepository.getReviewsByProductId(productId);
    }

}
