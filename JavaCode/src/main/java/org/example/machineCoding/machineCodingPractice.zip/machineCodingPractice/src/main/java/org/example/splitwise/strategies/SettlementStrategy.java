package org.example.splitwise.strategies;

import org.example.splitwise.dtos.Transaction;

import java.util.List;
import java.util.Map;

public interface SettlementStrategy {
    public List<Transaction> settleUpGroup(Map<Long,Double> userAmountMap);
}
