package org.example.ecomm.services;

import org.example.ecomm.models.User;
import org.example.ecomm.repositories.UserRepository;

public class UserService {
    private UserRepository userRepository;
    public UserService(UserRepository userRepository){
        this.userRepository = userRepository;
    }
    public User saveUser(User user){
        return userRepository.saveUser(user);
    }
    public User getUser(Long id){
        return userRepository.getUser(id);
    }
}
