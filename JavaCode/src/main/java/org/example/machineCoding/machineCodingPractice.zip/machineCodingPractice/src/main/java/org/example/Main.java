package org.example;

import org.apache.commons.codec.binary.Hex;

import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import javax.crypto.Cipher;

//import org.apache.commons.codec.binary.Hex;

public class Main {
    public static void main(String[] args) {
        String encryptionKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqz7Es/GH7iaU5IZHXkKIYlW5kBETnBHYNyVc9dG0RpwPc6W5SVZNjaWWzngfscXIqjPEIEXPHg/qSjFBn1nq02l3b+lmR/kMY5VCEBGCz/IyGEgoMtER66FIHapEcy2Yd5aWL6bDvQWVIXPj5ZFT3fznkaklPbDGN6YP5zG9Q5Bx/Q7RjxNRLbsCmJSDeoyiwULzK/Xs2kVTzpKYJJ+JODn/h5dOleI7SGkx4dZDN6r4HnGPpNK8JujezBXlkgivmcCUplSWdZ0N3GmUBpcVWOUW2voXd2LkXqLhzT5X5ixWg6ATirTg+wYi7NYM3BhA6w5sJ2bEMf9SLOUZ0NxWaQIDAQAB";
        String mpin ="1111";
        try {
            //Hash
            String hashedMpin = generateSha256Hash(mpin);
            hashedMpin = System.currentTimeMillis()+"_"+hashedMpin;
            byte[] encryptedByte = encryptUsingPublicKey(Base64.getDecoder().decode(encryptionKey), hashedMpin.getBytes());
            String encryptedMpin = new String(Base64.getEncoder().encode(encryptedByte));

            System.out.println("Encrypted MPIN: " + encryptedMpin);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static byte[] encryptUsingPublicKey(PublicKey key, byte[] data) {
        byte[] cipherText = null;
        try {
            final Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            cipherText = cipher.doFinal(data);
        } catch (Exception e) {
            System.out.println("Error while encrypting data using public key" + data);
        }
        return Base64.getEncoder().encode(cipherText);
    }

    public static byte[] encryptUsingPublicKey(byte[] key, byte[] data) {
        PublicKey publicKey = null;
        try {
            publicKey = KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(key));
        } catch (Exception e) {
            System.out.println("Error while generating public key from byte array" + key);
        }
        return encryptUsingPublicKey(publicKey, data);
    }

    public static String generateSha256Hash(String data) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(data.getBytes());
            byte[] b = md.digest();
            return Hex.encodeHexString(b);
        } catch (Exception e) {
            System.out.println("Error while generating SHA-256 hash" + data);
        }
        return "";
    }
}