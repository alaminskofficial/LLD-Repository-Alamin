package org.example.ecomm.repositories;

import org.example.ecomm.models.Order;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class OrderRepository {
    private Map<Long, Order> orderMap;
    public OrderRepository() {
        this.orderMap = new HashMap<>();
    }
    public Order saveOrder(Order order){
        if(order.getId() == null){
            order.setId((long) (orderMap.size()+1));
        }
        orderMap.put(order.getId(), order);
        return order;
    }
    public Order getOrder(Long id){
        return orderMap.get(id);
    }
    public List<Order> getOrdersByUserId(Long userId){
        List<Order> orders = new ArrayList<>();
        for(Order order : orderMap.values()){
            if(order.getUser().getId().equals(userId)){
                orders.add(order);
            }
        }
        return orders;
    }

}
