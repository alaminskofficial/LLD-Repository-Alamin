package org.example.wallet.exceptions;

public class SufficientBalanceNotAvailableException extends Exception{
    public SufficientBalanceNotAvailableException(String msg){
        super(msg);
    }
}
