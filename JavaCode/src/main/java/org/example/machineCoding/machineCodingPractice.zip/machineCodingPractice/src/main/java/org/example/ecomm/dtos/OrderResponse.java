package org.example.ecomm.dtos;

import java.util.Date;

public class OrderResponse {
    private Long UserId;
    private Long cartId;
    private Long orderId;
    private Double orderAmount;
    private String orderStatus;
    private String paymentStatus;
    private String message;
    private Date orderDate;

    public Long getUserId() {
        return UserId;
    }

    public void setUserId(Long userId) {
        UserId = userId;
    }

    public Long getCartId() {
        return cartId;
    }

    public void setCartId(Long cartId) {
        this.cartId = cartId;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }
    public String getPaymentStatus() {
        return paymentStatus;
    }
    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }
    public Double getOrderAmount() {
        return orderAmount;
    }
    public void setOrderAmount(Double orderAmount) {
        this.orderAmount = orderAmount;
    }



    @Override
    public String toString() {
        return "OrderResponse{" +
                "UserId=" + UserId +
                ", cartId=" + cartId +
                ", orderId=" + orderId +
                ", orderStatus='" + orderStatus + '\'' +
                ", paymentStatus='" + paymentStatus + "'"+
                ", message='" + message + '\'' +
                ", orderDate=" + orderDate +
                ", orderAmount='" + orderAmount + "'"+
                '}';
    }
}
