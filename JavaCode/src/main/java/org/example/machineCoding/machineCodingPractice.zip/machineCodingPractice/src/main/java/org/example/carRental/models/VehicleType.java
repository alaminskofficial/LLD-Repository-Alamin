package org.example.carRental.models;

public enum VehicleType {
    SUV,SEDAN,BIKE,HATCHBACK
}
