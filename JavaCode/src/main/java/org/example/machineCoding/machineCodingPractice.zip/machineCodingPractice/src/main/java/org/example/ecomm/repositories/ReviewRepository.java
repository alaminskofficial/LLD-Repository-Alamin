package org.example.ecomm.repositories;

import org.example.ecomm.models.Review;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ReviewRepository {
    private Map<Long, Review> reviewMap;
    public  ReviewRepository(){
        this.reviewMap = new HashMap<>();
    }
    public Review saveReview(Review review){
        if(review.getId() == null){
            review.setId((long) (reviewMap.size()+1));
        }
        reviewMap.put(review.getId(), review);
        return review;
    }
    public Review getReview(Long id){
        return reviewMap.get(id);
    }
    public List<Review> getReviewsByUserId(Long userId){
        List<Review> reviews = new ArrayList<>();
        for(Review review : reviewMap.values()){
            if(review.getUser().getId().equals(userId)){
                reviews.add(review);
            }
        }
        return reviews;
    }
    public List<Review> getReviewsByProductId(Long productId){
        List<Review> reviews = new ArrayList<>();
        for(Review review : reviewMap.values()){
            if(review.getProduct().getId().equals(productId)){
                reviews.add(review);
            }
        }
        return reviews;
    }

}
