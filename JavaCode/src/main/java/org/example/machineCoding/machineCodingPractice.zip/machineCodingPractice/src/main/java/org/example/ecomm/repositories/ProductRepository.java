package org.example.ecomm.repositories;

import org.example.ecomm.models.Product;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ProductRepository {
    private Map<Long, Product> productMap;
    public ProductRepository() {
        this.productMap = new HashMap<>();
    }
    public Product saveProduct(Product product){
        if(product.getId() == null){
            product.setId((long) (productMap.size()+1));
        }
        productMap.put(product.getId(), product);
        return product;
    }
    public Product getProduct(Long id){
        return productMap.get(id);
    }
    public List<Product> productList(){
        return productMap.values().stream().collect(Collectors.toList());
    }

}
