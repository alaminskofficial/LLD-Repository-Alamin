package org.example.wallet.services;

import org.example.wallet.exceptions.SufficientBalanceNotAvailableException;
import org.example.wallet.exceptions.UserNotFoundException;
import org.example.wallet.models.User;
import org.example.wallet.repositories.UserRepositoryImpl;

import java.math.BigDecimal;
import java.util.Optional;

public class UserServiceImpl {
    private UserRepositoryImpl userRepository;

    public UserServiceImpl(UserRepositoryImpl userRepository){
        this.userRepository = userRepository;
    }

    public User createUser(User user){
        return  userRepository.saveUser(user);
    }
    public Optional<User> findUserById(Long id){
        return  userRepository.findUserById(id);
    }
    public User addFundToUserWallet(BigDecimal fund , Long userId) throws UserNotFoundException {
        User user = userRepository.findUserById(userId).get();
        if(user == null){
            throw new  UserNotFoundException("User Not Found Exception");
        }
        user.setWalletBalance(user.getWalletBalance().add(fund));
        return userRepository.saveUser(user);
    }
    public void sendMoney(Long senderId , Long receiverId , BigDecimal amount) throws UserNotFoundException, SufficientBalanceNotAvailableException {
        User sender = userRepository.findUserById(senderId).get();
        User receiver = userRepository.findUserById(receiverId).get();
        if(sender == null || receiver == null){
            throw new UserNotFoundException("User not found Exception");
        }
        if(sender.getWalletBalance().compareTo(amount) >= 0){
            sender.setWalletBalance(sender.getWalletBalance().subtract(amount));
            userRepository.saveUser(sender);
            receiver.setWalletBalance(receiver.getWalletBalance().add(amount));
            userRepository.saveUser(receiver);
        }else{
            throw  new SufficientBalanceNotAvailableException("Sufficient Balance not Available");
        }

    }



}
