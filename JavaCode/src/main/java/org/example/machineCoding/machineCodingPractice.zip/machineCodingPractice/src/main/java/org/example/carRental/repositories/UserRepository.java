package org.example.carRental.repositories;

import org.example.carRental.models.User;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class UserRepository {
    private Map<Long ,User> userMap ;
    public UserRepository(){
        this.userMap = new HashMap<>();
    }
    public User saveUser(User user){
        if(user.getId() == null){
            user.setId(userMap.size() + 1L);
        }
        userMap.put(user.getId(), user);
        return user;
    }
    public User getUserById(Long userId){
        return userMap.get(userId);
    }
    public List<User> userList(){
        return  userMap.values().stream().collect(Collectors.toList());
    }
}
