package org.example.ecomm.models;

public enum UserType {
    BUYER,SELLER
}
