package org.example.ecomm.models;

public enum PaymentStatus {
    PAYMENT_PENDING,
    PAYMENT_FAILED,
    PAYMENT_SUCCESSFUL,
    PAYMENT_CANCELLED

}
