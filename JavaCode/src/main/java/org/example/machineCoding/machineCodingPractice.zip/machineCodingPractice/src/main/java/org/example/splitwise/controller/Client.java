package org.example.splitwise.controller;

import org.example.splitwise.dtos.Transaction;
import org.example.splitwise.models.*;
import org.example.splitwise.repositories.ExpenseRepository;
import org.example.splitwise.repositories.GroupRepository;
import org.example.splitwise.repositories.UserExpenseRepository;
import org.example.splitwise.repositories.UserRepository;
import org.example.splitwise.services.SettlementService;
import org.example.splitwise.strategies.HeapSettlementStrategyImpl;
import org.example.splitwise.strategies.SettlementStrategy;


import java.util.ArrayList;
import java.util.List;

public class Client {
    public static void main(String[] args) {
        ExpenseRepository expenseRepository = new ExpenseRepository();
        UserRepository userRepository = new UserRepository();
        GroupRepository groupRepository = new GroupRepository();
        UserExpenseRepository userExpenseRepository = new UserExpenseRepository();
        SettlementStrategy settlementStrategy = new HeapSettlementStrategyImpl();
        SettlementService settlementService = new SettlementService(userRepository,expenseRepository,userExpenseRepository,groupRepository,settlementStrategy);

        User user1 = new User(1l , "SK", "1234567890");
        User user2 = new User(2l , "RK", "1234567890");
        User user3 = new User(3l , "PK", "1234567890");
        User user4 = new User(4l , "MK", "1234567890");
        User user5 = new User(5l , "NK", "1234567890");

        userRepository.saveUser(user1);
        userRepository.saveUser(user2);
        userRepository.saveUser(user3);
        userRepository.saveUser(user4);
        userRepository.saveUser(user5);


        List<User> goaGuys = new ArrayList<>();
        goaGuys.add(user1);
        goaGuys.add(user2);
        goaGuys.add(user3);
        goaGuys.add(user4);
        goaGuys.add(user5);

        Group goaTrip = new Group(1l , "Goa Trip");
        goaTrip.setMembers(goaGuys);

        Expense expense1 = new Expense(1l , "Dinner" , 11000.0);
        expenseRepository.saveExpense(expense1);


        UserExpense userExpense1 = new UserExpense(1l , user1 , 2000.0 , expense1, UserExpenseType.HAD_TO_PAY);
        UserExpense userExpense2 = new UserExpense(2l , user2 , 2000.0 , expense1, UserExpenseType.HAD_TO_PAY);
        UserExpense userExpense3 = new UserExpense(3l , user3 , 2000.0 , expense1, UserExpenseType.HAD_TO_PAY);
        UserExpense userExpense4 = new UserExpense(4l , user4 , 2000.0 , expense1, UserExpenseType.HAD_TO_PAY);
        UserExpense userExpense5 = new UserExpense(5l , user5 , 3000.0 , expense1, UserExpenseType.HAD_TO_PAY);

        UserExpense userExpense6 = new UserExpense(6l , user1 , 11000.0 , expense1, UserExpenseType.PAID_BY);

        userExpenseRepository.saveUserExpense(userExpense1);
        userExpenseRepository.saveUserExpense(userExpense2);
        userExpenseRepository.saveUserExpense(userExpense3);
        userExpenseRepository.saveUserExpense(userExpense4);
        userExpenseRepository.saveUserExpense(userExpense5);

        userExpenseRepository.saveUserExpense(userExpense6);

        goaTrip.getExpenses().add(expense1);
        groupRepository.saveGroup(goaTrip);
        List<Transaction> txns =  settlementService.settlementTransactions(1L,1L);
        System.out.println(txns);

    }
}
