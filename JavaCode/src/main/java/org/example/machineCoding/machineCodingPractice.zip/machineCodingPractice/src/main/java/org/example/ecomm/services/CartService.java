package org.example.ecomm.services;

import org.example.ecomm.models.Cart;
import org.example.ecomm.repositories.CartRepository;

public class CartService {
    private CartRepository cartRepository;
    public CartService(CartRepository cartRepository){
        this.cartRepository = cartRepository;
    }
    public Cart saveCart(Cart cart){
        return cartRepository.saveCart(cart);
    }
    public Cart getCart(Long id){
        return cartRepository.getCart(id);
    }
    public Cart getCartByUserId(Long userId){
        return cartRepository.getCartByUserId(userId);
    }

}
