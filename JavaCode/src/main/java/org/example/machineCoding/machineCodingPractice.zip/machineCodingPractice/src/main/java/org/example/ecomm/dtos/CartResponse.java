package org.example.ecomm.dtos;

import org.example.ecomm.models.CartItem;

import java.util.List;

public class CartResponse {
    private Long userId;
    private List<CartItem> cartItems;
    private String status;
    private String message;

    public CartResponse() {
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public List<CartItem> getCartItems() {
        return cartItems;
    }

    public void setCartItems(List<CartItem> cartItems) {
        this.cartItems = cartItems;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "CartResponse{" +
                "userId=" + userId +
                ", cartItems=" + cartItems +
                ", status='" + status + '\'' +
                ", message='" + message + '\'' +
                '}';
    }
}
