package org.example.doctorAppointment.exceptions;

public class DoctorDetailsNotFoundException extends Exception{
    public DoctorDetailsNotFoundException(String msg){
        super(msg);
    }
}
