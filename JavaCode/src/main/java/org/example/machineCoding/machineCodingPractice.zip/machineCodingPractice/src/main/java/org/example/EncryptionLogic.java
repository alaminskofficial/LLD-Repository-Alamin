package org.example;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Base64;

public class EncryptionLogic {


    public String enctyptedData (String data) throws Exception {
        // encrypt data using symmetric key
        SecretKey getSymmetricKey = getAESKey();// symmetric key generated
        IvParameterSpec iv = generateIV();// generated iv
        String encBody = encrypt((data).getBytes(), getSymmetricKey, iv);
        return encBody;
    }


    public SecretKey getAESKey() throws NoSuchAlgorithmException, IOException {
        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
        keyGen.init(128, SecureRandom.getInstance("SHA1PRNG"));
        SecretKey secretKey = keyGen.generateKey();

        return secretKey;

    }
    public IvParameterSpec generateIV() throws Exception {
        IvParameterSpec iv = new IvParameterSpec("0001615873076144".getBytes());
        return iv;
    }
    public String encrypt(byte[] pText, SecretKey secret, IvParameterSpec iv) throws Exception {

        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, secret, iv);
        byte[] encryptedText = cipher.doFinal(pText);
        return new String(Base64.getEncoder().encode(encryptedText));

    }
}
