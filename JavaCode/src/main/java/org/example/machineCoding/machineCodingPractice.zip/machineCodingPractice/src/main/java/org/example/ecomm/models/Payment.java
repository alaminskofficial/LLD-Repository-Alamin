package org.example.ecomm.models;

public class Payment extends BaseModel{
     private Long userId;
     private Long orderId;
     private Double orderBillAmount;
     private PaymentMethod paymentMethod;
     private PaymentStatus paymentStatus;
     public Payment() {
     }
     public Payment(Long id, Long userId, Long orderId,Double orderBillAmount, PaymentMethod paymentMethod, PaymentStatus paymentStatus) {
         super(id);
         this.userId = userId;
         this.orderId = orderId;
         this.orderBillAmount = orderBillAmount;
         this.paymentMethod = paymentMethod;
         this.paymentStatus = paymentStatus;
     }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Double getOrderBillAmount() {
        return orderBillAmount;
    }

    public void setOrderBillAmount(Double orderBillAmount) {
        this.orderBillAmount = orderBillAmount;
    }

    public PaymentMethod getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(PaymentMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public PaymentStatus getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(PaymentStatus paymentStatus) {
        this.paymentStatus = paymentStatus;
    }
}
