package org.example.wallet.controller;

import org.example.wallet.dtos.TransactionRequest;
import org.example.wallet.dtos.TransactionResponse;
import org.example.wallet.exceptions.SufficientBalanceNotAvailableException;
import org.example.wallet.exceptions.UserNotFoundException;
import org.example.wallet.models.Transaction;
import org.example.wallet.models.User;
import org.example.wallet.repositories.TransactionRepositoryImpl;
import org.example.wallet.repositories.UserRepositoryImpl;
import org.example.wallet.services.TransactionServiceImpl;
import org.example.wallet.services.UserServiceImpl;

import javax.sound.midi.Soundbank;
import java.math.BigDecimal;
import java.util.List;

public class App {
    public static void main(String[] args) throws UserNotFoundException, SufficientBalanceNotAvailableException {
        UserRepositoryImpl userRepository = new UserRepositoryImpl();
        TransactionRepositoryImpl transactionRepository = new TransactionRepositoryImpl();
        UserServiceImpl userService = new UserServiceImpl(userRepository);

        User alamin = new User(1L,"Alamin","alamin@gmail.com" , BigDecimal.valueOf(100));
        User savedAlamin = userService.createUser(alamin);
        System.out.println(savedAlamin);

        User khadija = new User(2L,"Khadija","khadija@gmail.com" , BigDecimal.valueOf(210));
        User savedKhadija = userService.createUser(khadija);
        System.out.println(savedKhadija);

        TransactionServiceImpl transactionService = new TransactionServiceImpl(transactionRepository,userRepository);
        WalletController controller = new WalletController(userService,transactionService);
        //        adding fund
        User alaminUserData = controller.addFundToWallet(BigDecimal.valueOf(340),1L);
        System.out.println(alaminUserData);

//        transferring money between users
        TransactionRequest request = new TransactionRequest(1L, 2L,BigDecimal.valueOf(40));
        TransactionResponse txnResponse = controller.transferMoney(request);
        System.out.println(txnResponse);

//        view txn history etc
        List<Transaction>  viewHistory = controller.viewHistory();
        viewHistory.stream().forEach(System.out::println);
    }
}
