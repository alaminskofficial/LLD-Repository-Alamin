package org.example.carRental.services;

import org.example.carRental.models.Vehicle;
import org.example.carRental.repositories.VehicleRepository;

import java.util.List;

public class VehicleService {
    private VehicleRepository vehicleRepository;
    public VehicleService(VehicleRepository vehicleRepository) {
        this.vehicleRepository = vehicleRepository;
    }
    public Vehicle getVehicleById(Long id) {
        return vehicleRepository.getVehicleById(id);
    }
    public Vehicle saveVehicle(Vehicle vehicle) {
        return vehicleRepository.saveVehicle(vehicle);
    }
    public void saveAll(List<Vehicle> vehicleList){
        for(Vehicle veh : vehicleList){
            vehicleRepository.saveVehicle(veh);
        }
    }
    public void deleteVehicle(Long id) {
        vehicleRepository.deleteVehicle(id);
    }
    public List<Vehicle> vehicleList() {
        return vehicleRepository.vehicleList();
    }

}
