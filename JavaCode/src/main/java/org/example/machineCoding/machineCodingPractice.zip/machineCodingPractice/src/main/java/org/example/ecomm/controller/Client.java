package org.example.ecomm.controller;

import org.example.ecomm.dtos.*;
import org.example.ecomm.exceptions.UserNotASellerException;
import org.example.ecomm.models.*;
import org.example.ecomm.repositories.*;
import org.example.ecomm.services.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Client {
    public static void main(String[] args) throws UserNotASellerException {
//        The website should have two types of users: buyers and sellers.
        UserRepository userRepository = new UserRepository();
        UserService userServices = new UserService(userRepository);
        UserController userController = new UserController(userServices);

        User buyer = new User(null,"SK","a@gmail.com", UserType.BUYER,"12345","Bangalore");
        User seller = new User(null,"RK","r@gmail.com", UserType.SELLER,"12345","Bangalore");
        User saveBuyer = userController.saveUser(buyer);
        User saveSeller = userController.saveUser(seller);
        System.out.println(saveBuyer);
        System.out.println(saveSeller);

//        Sellers should be able to add, delete and modify products they want to sell.
        ProductRepository productRepository = new ProductRepository();
        ProductService productService = new ProductService(productRepository);
        ProductController productController = new ProductController(productService);

        Product product = new Product(null , "Laptop" ,"Dell Laptop",  50000.0,20L,ProductCategory.ELECTRONICS, saveSeller);
        Product saveProduct = productController.saveProduct(product);
        System.out.println(saveProduct);
//        The website should show a catalog of products.
        System.out.println(productController.productList());
//        Buyers can add, delete or update items in a cart.
        CartRepository cartRepository = new CartRepository();
        CartService cartService = new CartService(cartRepository);
        CartController cartController = new CartController(cartService);
        CartRequest cartRequest = new CartRequest();
        cartRequest.setUserId(saveBuyer.getId());
        CartItem product1 = new CartItem();
        product1.setProduct(saveProduct);
        product1.setQuantity(2L);
        saveProduct.setQuantity(saveProduct.getQuantity()-product1.getQuantity());
        productService.saveProduct(saveProduct);
        List<CartItem> cartItems = new ArrayList<>();
        cartItems.add(product1);
        cartRequest.setCartItems(cartItems);
        CartResponse cartResponse = cartController.addToCart(cartRequest);
        System.out.println(cartResponse);
        System.out.println(saveProduct);

//        Buyers can purchase items in the cart and make payments.
        OrderRepository orderRepository = new OrderRepository();
        OrderService orderService = new OrderService(orderRepository);
        OrderController orderController = new OrderController(orderService, cartService, userServices);
        OrderRequest orderRequest = new OrderRequest();
        orderRequest.setUserId(saveBuyer.getId());
        orderRequest.setCartId(cartController.getCart(saveBuyer.getId()).getId());
        OrderResponse orderResponse = orderController.placeOrder(orderRequest);
        System.out.println(orderResponse);

        // payments are pending
        PaymentRequest paymentRequest = new PaymentRequest();
        paymentRequest.setOrderId(orderResponse.getOrderId());
        paymentRequest.setPaymentMethod(PaymentMethod.CREDIT_CARD);
        paymentRequest.setUserId(saveBuyer.getId());
        paymentRequest.setPaymentDate(new Date());
        PaymentController paymentController = new PaymentController(new PaymentService(new PaymentRepository()), orderService);
        PaymentResponse paymentResponse = paymentController.makePayment(paymentRequest);
        System.out.println(paymentResponse);

        // payments are successful
        Order order = orderService.getOrder(orderResponse.getOrderId());
        order.setPaymentStats(PaymentStatus.PAYMENT_SUCCESSFUL);
        order.setStatus(OrderStatus.DELIVERED);
        Order updateOrder = orderService.saveOrder(order);
        System.out.println(updateOrder);

//        Buyers can view their previous orders.

        System.out.println(orderController.getOrdersByUserId(saveBuyer.getId()));

//        Buyers can review and rate purchased products.
        ReviewRepository reviewRepository = new ReviewRepository();
        ReviewService reviewService = new ReviewService(reviewRepository);
        ReviewController reviewController = new ReviewController(reviewService, productService, userServices);
        ReviewRequest reviewRequest = new ReviewRequest();
        reviewRequest.setUserId(saveBuyer.getId());
        reviewRequest.setProductId(saveProduct.getId());
        reviewRequest.setRating(4L);
        reviewRequest.setReview("Good Product");
        ReviewResponse reviewResponse = reviewController.addReview(reviewRequest);
        System.out.println(reviewResponse);

    }
}
