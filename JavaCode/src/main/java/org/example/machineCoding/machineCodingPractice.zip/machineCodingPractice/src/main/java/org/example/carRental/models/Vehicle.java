package org.example.carRental.models;

public class Vehicle extends  BaseModel{
    private VehicleType type;
    private double rentPerHour;
    private VehicleStatusType vehicleStatusType;

    public Vehicle(Long id, VehicleType type, double rentPerHour ,VehicleStatusType vehicleStatusType) {
        super(id);
        this.type = type;
        this.rentPerHour = rentPerHour;
        this.vehicleStatusType = vehicleStatusType;
    }

    public VehicleType getType() {
        return type;
    }

    public void setType(VehicleType type) {
        this.type = type;
    }

    public double getRentPerHour() {
        return rentPerHour;
    }

    public void setRentPerHour(double rentPerHour) {
        this.rentPerHour = rentPerHour;
    }

    public VehicleStatusType getVehicleStatusType() {
        return vehicleStatusType;
    }

    public void setVehicleStatusType(VehicleStatusType vehicleStatusType) {
        this.vehicleStatusType = vehicleStatusType;
    }

    @Override
    public String toString() {
        return "Vehicle{" +
                "type=" + type +
                ", rentPerHour=" + rentPerHour +
                ", vehicleStatusType=" + vehicleStatusType +
                '}';
    }
}
