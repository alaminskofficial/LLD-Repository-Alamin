package org.example.splitwise.services;

import org.example.splitwise.dtos.Transaction;
import org.example.splitwise.models.Expense;
import org.example.splitwise.models.User;
import org.example.splitwise.models.UserExpense;
import org.example.splitwise.models.UserExpenseType;
import org.example.splitwise.repositories.ExpenseRepository;
import org.example.splitwise.repositories.GroupRepository;
import org.example.splitwise.repositories.UserExpenseRepository;
import org.example.splitwise.repositories.UserRepository;
import org.example.splitwise.strategies.SettlementStrategy;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SettlementService {
    private UserRepository userRepository;
    private ExpenseRepository expenseRepository;
    private UserExpenseRepository userExpenseRepository;
    private GroupRepository groupRepository;
    private SettlementStrategy settlementStrategy;
    public SettlementService(UserRepository userRepository, ExpenseRepository expenseRepository, UserExpenseRepository userExpenseRepository, GroupRepository groupRepository,SettlementStrategy settlementStrategy) {
        this.userRepository = userRepository;
        this.expenseRepository = expenseRepository;
        this.userExpenseRepository = userExpenseRepository;
        this.groupRepository = groupRepository;
        this.settlementStrategy = settlementStrategy;
    }
    public List<Transaction> settlementTransactions(Long userId, Long groupId){
        Map<Long, Double> userAmountMap = new HashMap<>();
        //1. Get all the expenses of the group
        List<Expense> expenses = groupRepository.getGroup(groupId).getExpenses();

        //2. Get all the user expenses of the expenses
        //3. Create a map of UserId , Amount-for settlement
        //4. For each user expense, update the map(Add the amount if user is lender, subtract if user is borrower)

        for(Expense expense: expenses){
            List<UserExpense> userExpenses = userExpenseRepository.getUserExpensesByExpenseId(expense.getId());
            for(UserExpense userExpense: userExpenses){
                User user = userExpense.getUser();
                if(!userAmountMap.containsKey(user.getId())){
                    userAmountMap.put(user.getId(), 0.0);
                }
                double amount = userAmountMap.get(user.getId());
                if(userExpense.getUserExpenseType().equals(UserExpenseType.PAID_BY)){
                    amount += userExpense.getAmount();
                }
                if(userExpense.getUserExpenseType().equals(UserExpenseType.HAD_TO_PAY)){
                    amount -= userExpense.getAmount();
                }
                userAmountMap.put(user.getId(), amount);
            }
        }
        //5. settle the amount with map data(using heap strategy)
        List<Transaction> txns = settlementStrategy.settleUpGroup(userAmountMap);

        //6. return the transactions w.r.t userId
        List<Transaction> userTransactions = new ArrayList<>();
        for(Transaction transaction: txns){
            if(transaction.getFrom().equalsIgnoreCase(userId.toString()) || transaction.getTo().equalsIgnoreCase(userId.toString())){
                userTransactions.add(transaction);
            }
        }
        return userTransactions;

    }

}
