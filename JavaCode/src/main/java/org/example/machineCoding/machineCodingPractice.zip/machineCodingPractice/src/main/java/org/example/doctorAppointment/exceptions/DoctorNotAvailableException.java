package org.example.doctorAppointment.exceptions;

public class DoctorNotAvailableException extends Exception{
    public DoctorNotAvailableException(String msg){
        super(msg);
    }
}
