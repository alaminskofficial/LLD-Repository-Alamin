package org.example.carRental.repositories;

import org.example.carRental.models.Station;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class StationRepository {
    private Map<Long , Station> stationMap;
    public StationRepository(){
        stationMap = new HashMap<>();
    }
    public Station saveStation(Station station){
        if(station.getId() == null){
            station.setId(stationMap.size() + 1L);
        }
        stationMap.put(station.getId(), station);
        return station;
    }
    public Station getStationById(Long stationId){
        return stationMap.get(stationId);
    }
    public List<Station> stationList(){
        return stationMap.values().stream().collect(Collectors.toList());
    }
    public void deleteStation(Long stationId){
        stationMap.remove(stationId);
    }


}
