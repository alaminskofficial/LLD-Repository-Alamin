package org.example.ecomm.services;

import org.example.ecomm.models.Payment;
import org.example.ecomm.repositories.PaymentRepository;

public class PaymentService {
    private PaymentRepository paymentRepository;
    public PaymentService(PaymentRepository paymentRepository){
        this.paymentRepository = paymentRepository;
    }
    public Payment savePayment(Payment payment){
        return paymentRepository.savePayment(payment);
    }
    public Payment getPayment(Long id){
        return paymentRepository.getPayment(id);
    }
    public Payment getPaymentByOrderId(Long orderId){
        return paymentRepository.getPaymentByOrderId(orderId);
    }



}
