package org.example.ecomm.controller;

import org.example.ecomm.exceptions.UserNotASellerException;
import org.example.ecomm.models.Product;
import org.example.ecomm.services.ProductService;

import java.util.List;

public class ProductController {
    private ProductService productService;
    public ProductController(ProductService productService){
        this.productService = productService;
    }
    public Product saveProduct(Product product) throws UserNotASellerException {
        return productService.saveProduct(product);
    }
    public Product getProduct(Long id){
        return productService.getProduct(id);
    }
    public List<Product> productList(){
        return productService.productList();
    }

}
